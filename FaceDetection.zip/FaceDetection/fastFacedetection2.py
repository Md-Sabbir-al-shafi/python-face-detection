import cv2
import face_recognition
import os
import concurrent.futures

photo_dir = r'E:\CIFT-TechTopia\Project\FaceDetection\photos'
known_face_encodings = []
known_face_names = []

for file_name in os.listdir(photo_dir):
    if file_name.endswith('.jpg') or file_name.endswith('.png'):
        image_path = os.path.join(photo_dir, file_name)
        image = face_recognition.load_image_file(image_path)
        encoding = face_recognition.face_encodings(image)[0]
        known_face_encodings.append(encoding)
        known_face_names.append(os.path.splitext(file_name)[0])

def process_frame(frame):
    small_frame = cv2.resize(frame, (0, 0), fx=0.5, fy=0.5)
    rgb_frame = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)
    face_locations = face_recognition.face_locations(rgb_frame)
    face_encodings = face_recognition.face_encodings(rgb_frame, face_locations)
    return face_locations, face_encodings

video_capture = cv2.VideoCapture(0)

with concurrent.futures.ThreadPoolExecutor() as executor:
    while True:
        ret, frame = video_capture.read()
        if not ret:
            print("Error: Could not read frame.")
            break

        # Process the frame in a separate thread
        future = executor.submit(process_frame, frame)
        face_locations, face_encodings = future.result()

        # Loop through each face found in the frame
        for (top, right, bottom, left), face_encoding in zip(face_locations, face_encodings):
            matches = face_recognition.compare_faces(known_face_encodings, face_encoding)
            name = "Unknown"
            if True in matches:
                first_match_index = matches.index(True)
                name = known_face_names[first_match_index]
            print(f"Detected face: {name}")

        # Display the resulting frame
        cv2.imshow('Video', frame)

        print(f"Detected face: {name}")
        if name != "Unknown":
            dt = "b"
            #ser.write(dt.encode())
            data = {
                'name': name
            }

        else:
            dt = "a"
             
        cv2.imshow('Video', frame) 
        if cv2.waitKey(1) & 0xFF == ord('q'):
         break


video_capture.release()
cv2.destroyAllWindows()
#ser.close()