import cv2
import face_recognition
import os
import concurrent.futures

# Path to the folder with known faces
photo_dir = r'E:\CIFT-TechTopia\Project\FaceDetection\photos'
known_face_encodings = []
known_face_names = []

# Load known faces from images in the folder
for file_name in os.listdir(photo_dir):
    if file_name.endswith('.jpg') or file_name.endswith('.png'):
        image_path = os.path.join(photo_dir, file_name)
        image = face_recognition.load_image_file(image_path)
        encoding = face_recognition.face_encodings(image)[0]
        known_face_encodings.append(encoding)
        known_face_names.append(os.path.splitext(file_name)[0])  # Name from the file name (without extension)

# Function to process frames in parallel
def process_frame(frame):
    small_frame = cv2.resize(frame, (0, 0), fx=0.5, fy=0.5)  # Resize for faster processing
    rgb_frame = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)  # Convert to RGB
    face_locations = face_recognition.face_locations(rgb_frame)  # Detect faces
    face_encodings = face_recognition.face_encodings(rgb_frame, face_locations)  # Get encodings of faces
    return face_locations, face_encodings

# Open the external webcam (use index 1 for external webcam)
video_capture = cv2.VideoCapture(1)

# Check if the video capture is initialized successfully
if not video_capture.isOpened():
    print("Error: Could not access the webcam.")
    exit()

# Using ThreadPoolExecutor for parallel frame processing
with concurrent.futures.ThreadPoolExecutor() as executor:
    while True:
        ret, frame = video_capture.read()  # Capture a frame from the webcam
        if not ret:
            print("Error: Could not read frame.")
            break

        # Process the frame in a separate thread
        future = executor.submit(process_frame, frame)
        face_locations, face_encodings = future.result()  # Get face locations and encodings

        # Loop through each face found in the frame
        for (top, right, bottom, left), face_encoding in zip(face_locations, face_encodings):
            # Compare the detected face with known faces
            matches = face_recognition.compare_faces(known_face_encodings, face_encoding)
            name = "Unknown"  # Default name for unknown faces

            # If a match is found, get the name of the matched face
            if True in matches:
                first_match_index = matches.index(True)
                name = known_face_names[first_match_index]

            # Display the name on the console
            print(f"Detected face: {name}")

            # Draw a rectangle around the face and display the name
            cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)  # Green box
            cv2.putText(frame, name, (left, top - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

        # Show the frame with the detected face(s)
        cv2.imshow('Video', frame)

        # Exit the loop if 'q' is pressed
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

# Release the webcam and close all windows
video_capture.release()
cv2.destroyAllWindows()
